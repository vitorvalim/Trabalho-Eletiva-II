var pontos_t = 0


var somjogo = document.getElementById("somjogo")
var atk_player_sound = document.getElementById("atk_player_sound")
var atk_boss_sound = document.getElementById("atk_boss_sound")
var atk_inimigo_sound = document.getElementById("atk_inimigo_sound")
var collect_coin_sound = document.getElementById("collect_coin_sound")


var teclas = {
    W: 87,
    S: 83,
    A: 65,
    D: 68,
    E: 69,
    Q: 81
}
var jogo = {}
jogo.precionou = []

$(document).keydown(function (e) {

    jogo.precionou[e.which] = true
}
)


$(document).keyup(function (e) {
    jogo.precionou[e.which] = false
}
)


function movimenta_player() {
    var width_tela = $(window).width()
    var heigth_tela = $(window).height()
    var width_palyer = parseInt($('#player').css("width"))
    var height_palyer = parseInt($('#player').css("height"))
    var lado = document.querySelector(':root');
    lado.style.setProperty('--passos', 1);



    if (jogo.precionou[teclas.E]) {
        tiro()
        lado.style.setProperty('--personagem', 'url("../img/player/atk_p.png")');
        lado.style.setProperty('--passos', 4);

        atk_player_sound.play()
    }
    if (jogo.precionou[teclas.W]) {

        lado.style.setProperty('--personagem', 'url("../img/player/W.png")');
        var mv_up = lado.style.setProperty('--personagem', 'url("../img/player/W.png")');
        lado.style.setProperty('--passos', 4)
        var pos_top = $('#player').css("top")
        pos_top = parseInt(pos_top)
        if (pos_top > 0) {
            $('#player').css("top", pos_top - 5)
            mv_up
            lado.style.setProperty('--passos', 4);
        }
        if (pos_top < (heigth_tela * 0.4)) {
            $('#player').css("top", pos_top)
            lado.style.setProperty('--passos', 1);
        }
    }
    if (jogo.precionou[teclas.S]) {
        lado.style.setProperty('--passos', 4)
        var lado = document.querySelector(':root');
        lado.style.setProperty('--personagem', 'url("../img/player/S.png")');

        var pos_top = $('#player').css("top")
        pos_top = parseInt(pos_top)
        //console.log(pos_top)
        if (pos_top < heigth_tela - height_palyer) {
            $('#player').css("top", pos_top + 5)
            lado.style.setProperty('--passos', 4);
        }
        if (pos_top > (heigth_tela * 0.72)) {
            $('#player').css("top", pos_top)
            lado.style.setProperty('--passos', 1);
        }

    }
    if (jogo.precionou[teclas.D]) {

        lado.style.setProperty('--passos', 4)
        if (jogo.precionou[teclas.W])
            lado.style.setProperty('--personagem', 'url("../img/player/DW.png")');
        else if (jogo.precionou[teclas.S])
            lado.style.setProperty('--personagem', 'url("../img/player/DS.png")');
        else
            lado.style.setProperty('--personagem', 'url("../img/player/D.png")');

        var posicao = parseInt($('#area_jogo').css("background-position"))


        $('#area_jogo').css("background-position", posicao - 10)

    }
    if (jogo.precionou[teclas.A]) {
        lado.style.setProperty('--passos', 4)
        var lado = document.querySelector(':root');
        if (jogo.precionou[teclas.W])
            lado.style.setProperty('--personagem', 'url("../img/player/AW.png")');
        else if (jogo.precionou[teclas.S])
            lado.style.setProperty('--personagem', 'url("../img/player/AS.png")');
        else
            lado.style.setProperty('--personagem', 'url("../img/player/A.png")');

        var posicao = parseInt($('#area_jogo').css("background-position"))

        $('#area_jogo').css("background-position", posicao + 10)

    }
}

function movimenta_inimigo() {
    var inimigo_lado = document.querySelector(':root');
    var heigth_tela = $(window).height()
    var width_tela = $(window).width()
    var width_inimigo = parseInt($('#inimigo').css("width"))
    var height_inimigo = parseInt($('#inimigo').css("height"))

 

    var pos_top_player = $('#player').css("top")
    var pos_left = $('#inimigo').css("right")
    var pos_left_player = $('#player').css("right")
    var pos_top_inimigo = $('#inimigo').css("top")
    pos_left_player = parseInt(pos_left_player)
    pos_top_player = parseInt(pos_top_player)
    pos_top_inimigo = parseInt(pos_top_inimigo)
    pos_left = parseInt(pos_left)

    if (pos_left < width_tela - width_inimigo) {
        if (jogo.precionou[teclas.A]) {
            $('#inimigo').css("right", pos_left + 2)
            if (pos_top_inimigo = pos_top_player - 40) {
                $('#inimigo').css("top", pos_top_player + 5)
                inimigo_lado.style.setProperty('--mirror_i', 'scaleX(1)')
            }
            if (pos_left_player < pos_left) {
                inimigo_lado.style.setProperty('--mirror_i', 'scaleX(-1)')
                $('#inimigo').css("right", pos_left - 5)
                inimigo_andando()

            }
        }
        else if (jogo.precionou[teclas.D]) {
            $('#inimigo').css("right", pos_left + 15)
            if (pos_top_inimigo = pos_top_player - 40) {
                $('#inimigo').css("top", pos_top_player + 5)
                inimigo_lado.style.setProperty('--mirror_i', 'scaleX(1)')
                inimigo_andando()


            }
            if (pos_left_player < pos_left) {
                $('#inimigo').css("right", pos_left + 20)
                inimigo_lado.style.setProperty('--mirror_i', 'scaleX(-1)')
                inimigo_andando()


            }

        }

        else {
            $('#inimigo').css("right", pos_left + 7)
            if ((pos_left > width_tela * 0.3) && (pos_left_player >= pos_left)) {
                $('#inimigo').css("right", pos_left)
                inimigo_lado.style.setProperty('--mirror_i', 'scaleX(1)');
                inimigo_atacando()
                atk_inimigo()
                atk_inimigo_sound.play()
            }
            else if (pos_left_player < pos_left) {
                $('#inimigo').css("right", pos_left - 3)
                inimigo_lado.style.setProperty('--mirror_i', 'scaleX(-1)');
                inimigo_andando()
                $('#atk_inimigo').remove()

            }
        }
    }


    else {
        $('#inimigo').remove()
        $('#atk_inimigo').remove()
        inimigo_andando()
        novo_inimigo()

    }

}

function movimenta_boss() {
    var boss_lado = document.querySelector(':root');
    boss_lado.style.setProperty('--mirror', 'scaleX(1)');
    var heigth_tela = $(window).height()
    var width_tela = $(window).width()
    var width_boss = parseInt($('#boss').css("width"))
    var height_boss = parseInt($('#boss').css("height"))




    var pos_top_player = $('#player').css("top")
    var pos_left = $('#boss').css("right")
    var pos_left_player = $('#player').css("right")
    var pos_top_boss = $('#boss').css("top")
    pos_left_player = parseInt(pos_left_player)
    pos_top_player = parseInt(pos_top_player)
    pos_top_boss = parseInt(pos_top_boss)
    pos_left = parseInt(pos_left)

    if (pos_left < width_tela - width_boss) {
(pontos_t * 0.001)
        if (jogo.precionou[teclas.A]) {
            $('#boss').css("right", pos_left + 2)
            if (pos_top_boss = pos_top_player - 40) {
                boss_lado.style.setProperty('--mirror_b', 'scaleX(1)')
            }
            if (pos_left_player < pos_left) {
                boss_lado.style.setProperty('--mirror_b', 'scaleX(-1)')
                $('#boss').css("right", pos_left - 5)
                boss_lado.style.setProperty('--mirror_b', 'scaleX(1)');
                boss_andando()

            }
        }
        else if (jogo.precionou[teclas.D]) {
            $('#boss').css("right", pos_left + 15)
            if (pos_top_boss = pos_top_player - 40) {
                boss_lado.style.setProperty('--mirror_b', 'scaleX(1)')
                boss_andando()


            }
            if (pos_left_player < pos_left) {
                boss_lado.style.setProperty('--mirror_b', 'scaleX(-1)')
                $('#boss').css("right", pos_left + 20)
                boss_lado.style.setProperty('--mirror_b', 'scaleX(1)');
                boss_andando()

            }

        }

        else {
            $('#boss').css("right", pos_left + 7)
            if ((pos_left > width_tela * 0.3) && (pos_left_player >= pos_left)) {
                $('#boss').css("right", pos_left)
                boss_lado.style.setProperty('--mirror_b', 'scaleX(1)');
                boss_atacando()
                atk_boss()
                atk_boss_sound.play()
                
            }
            else if (pos_left_player < pos_left) {
                $('#boss').css("right", pos_left - 3)
                boss_lado.style.setProperty('--mirror_b', 'scaleX(-1)');
                boss_andando()
                $('#atk_boss').remove()

            }
        }
    }


    else {
        $('#boss').remove()
        boss_andando()
        novo_boss()

    }

}
function ponto_movimento() {
    var width_tela = $(window).width()
    var width_pontos = parseInt($('#pontos').css("width"))

    var pos_left = $('#pontos').css("right")
    pos_left = parseInt(pos_left)
    if (pos_left < width_tela - width_pontos) {
        if (jogo.precionou[teclas.A]) {
            $('#pontos').css("right", pos_left - 20)
            if (pos_left < 0) {
                $('#pontos').remove()
            }
        }
        else if (jogo.precionou[teclas.D]) {
            $('#pontos').css("right", pos_left + 20)

        }
        else {
            $('#pontos').css("right", pos_left)
        }
    }

    else {
        $('#pontos').remove()
        novo_ponto()
    }
}

function atk_inimigo() {
    if ($("#atk_inimigo").length == 0) {
        var p_y_inimigo = parseInt($('#inimigo').css('top'))
        var p_x_inimigo = parseInt($('#inimigo').css('left'))
        $('#area_jogo').append("<div id='atk_inimigo'></div>")
        $('#atk_inimigo').css('top', p_y_inimigo + 20)
        $('#atk_inimigo').css('left', p_x_inimigo + 50)
    }
}

function movimenta_atk_inimigo() {
    var width_tela = $(window).width()
    var width_atk = parseInt($('#atk_inimigo').css("width"))
    if ($("#atk_inimigo").length > 0) {
        var tiro_x_inimigo = parseInt($('#atk_inimigo').css('left'))

        $('#atk_inimigo').css('left', tiro_x_inimigo - 15)
        if (0 >tiro_x_inimigo) {
            $('#atk_inimigo').remove()
        }
    }
}

function atk_boss() {
    if ($("#atk_boss").length == 0) {
        var p_y_boss = parseInt($('#boss').css('top'))
        var p_x_boss = parseInt($('#boss').css('left'))
        $('#area_jogo').append("<div id='atk_boss'></div>")
        $('#atk_boss').css('top', p_y_boss + 20)
        $('#atk_boss').css('left', p_x_boss - 150)
    }
}

function movimenta_atk_boss() {
    var width_tela = $(window).width()
    var width_atk = parseInt($('#atk_boss').css("width"))
    if ($("#atk_boss").length > 0) {
        var tiro_x_boss = parseInt($('#atk_boss').css('left'))

        $('#atk_boss').css('left', tiro_x_boss - 15)
        if (0 > tiro_x_boss) {
            $('#atk_boss').remove()
        }
    }
}
function tiro() {
    if ($("#tiro").length == 0) {
        var p_y = parseInt($('#player').css('top'))
        var p_x = parseInt($('#player').css('left'))
        $('#area_jogo').append("<div id='tiro'></div>")
        $('#tiro').css('top', p_y + 20)
        $('#tiro').css('left', p_x + 50)
    }
}

function movimenta_tiro() {
    var width_tela = $(window).width()
    if ($("#tiro").length > 0) {
        var tiro_x = parseInt($('#tiro').css('left'))

        $('#tiro').css('left', tiro_x + 10)
        if ((tiro_x > width_tela * 0.72)) {
            $("#tiro").remove()
        }
    }
}


function movimenta_cenario() {
    var posicao = parseInt($('#area_jogo').css("background-position"))


    $('#area_jogo').css("background-position", posicao - 2)

}

function colisao() {
    var c_player_atk = $('#tiro').collision('#inimigo')
    var c_player_atk1 = $('#tiro').collision('#boss')
    var c_inimigo_atk = $('#player').collision('#atk_inimigo')
    var c_boss_atk = $('#player').collision('#atk_boss')
    var c_moeda = $('#player').collision('#pontos')


    //var c_inimigo_atk = $('#player').collision('#inimigo')
    var pos_left_player = parseInt($('#player').css("right"))
    var pos_top_player = parseInt($('#player').css("top"))
    var pos_top_tiro = parseInt($('#tiro').css("top"))
    var pos_left_inimigo = parseInt($('#inimigo').css("right"))
    var pos_top_inimigo = parseInt($('#inimigo').css("top"))
    var pos_top_boss = parseInt($('#boss').css("top"))
    var pos_left_boss = parseInt($('#boss').css("right"))
    var pos_left_tiro = parseInt($('#tiro').css("right"))
    var vida = parseInt($('#vida').css("max-width"))
    vida = parseInt(vida)

    if (c_player_atk.length > 0){
            $('#tiro').remove()
            $('#inimigo').remove()
            $('#area_jogo').append('<div id="inimigo_explode"></div>')
            $('#inimigo_explode').css('right', pos_left_inimigo)
            $('#inimigo_explode').css('top', pos_top_inimigo)
            setTimeout(function () {
                $('#inimigo_explode').remove()
                $('#atk_inimigo').remove()               
            }, 500)
            pontos_t += 100
        }
        
        if (c_player_atk1.length > 0) {
            
        $('#tiro').remove()
        $('#boss').remove()
        $('#area_jogo').append('<div id="boss_morre"></div>')
        $('#boss_morre').css('right', pos_left_boss)
        $('#boss_morre').css('top',pos_top_boss)
        
        setTimeout(function(){
            $('#boss_morre').remove()
            $('#atk_boss').remove()
        }, 800)
        pontos_t += 200
        }
        
        if (c_inimigo_atk.length > 0){
            $('#atk_inimigo').remove()
            $('#vida').css('max-width', vida - 60)
            
            if(vida <= 60){
                $('#vida').css('max-width', vida - 60)
                $('#area_jogo').append('<div id="game_over"></div>')
                $('#player').remove()
                $('#boss').remove()
                $('#inimigo').remove()

            }
        }
        
        if (c_boss_atk.length > 0){
  
            $('#atk_boss').remove()
            $('#vida').css('max-width', vida - 60)
            
            if(vida <= 60){
                $('#vida').css('max-width', vida - 60)
                $('#area_jogo').append('<div id="game_over"></div>')
                $('#player').remove()
                $('#boss').remove()
                $('#inimigo').remove()



        }
        }

        if (c_moeda.length > 0){
  
            $('#pontos').remove()
            collect_coin_sound.play()
            pontos_t += 300
        }
    }


function valida_pontuacao(){
    $('#pontuacao').text("Score : " + pontos_t);
}

function loop() {
    colisao()
    movimenta_player()
    movimenta_tiro()
    movimenta_atk_inimigo()
    valida_pontuacao()
    movimenta_atk_boss()
    movimenta_inimigo()
    movimenta_boss()

    somjogo.addEventListener("ended", function () {
        somjogo.currentTime = 0
        somjogo.play()
    }, false)
    somjogo.play()
    ponto_movimento()
}



function start() {
    $('#game_over').css('display','none');
    $('#alerta').css('display', 'none')
    $('#area_jogo').append('<div id="player"></div>')
    $('#area_jogo').append('<div id="vida"></div>')
    $('#area_jogo').append('<div id="pontuacao">0</div>')
    novo_inimigo()
    novo_boss()
    setInterval(loop, 30)
}



function novo_inimigo() {
    //inimigo_lado.style.setProperty('--mirror', 'scaleX(1)');
    $('#area_jogo').append('<div id="inimigo"></div>')
    var top = Math.random() * (660 - 360) + 360;
    $('#inimigo').css('top', top)
}

function novo_boss() {
    //inimigo_lado.style.setProperty('--mirror', 'scaleX(1)');
    $('#area_jogo').append('<div id="boss"></div>')
    var top = Math.random() * (660 - 360) + 360;
    $('#boss').css('top', top)  
}
function novo_ponto() {
    $('#area_jogo').append('<div id="pontos"></div>')
    var top = Math.random() * (660 - 360) + 360;
    $('#pontos').css('top', top)
}

function novo_atk() {
    $('#area_jogo').append('<div id="atk_inimigo"></div>')
    $('#atk_inimigo').css('top', top)
}
