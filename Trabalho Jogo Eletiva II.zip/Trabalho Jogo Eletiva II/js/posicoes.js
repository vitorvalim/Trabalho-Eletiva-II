var boss_lado = document.querySelector(':root');
var inimigo_lado = document.querySelector(':root');


function inimigo_andando(){
    inimigo_lado.style.setProperty('--passos_i', 8)
    inimigo_lado.style.setProperty('--widht_i', '133px')
    inimigo_lado.style.setProperty('--height_i', '158px')
    inimigo_lado.style.setProperty('--inimigo', 'url("../img/monster03.png")')
    inimigo_lado.style.setProperty('--width_i_total', '-1063px')
}
function inimigo_atacando(){
    inimigo_lado.style.setProperty('--passos_i', 4)
    inimigo_lado.style.setProperty('--widht_i', '137px')
    inimigo_lado.style.setProperty('--height_i', '159px')
    inimigo_lado.style.setProperty('--inimigo', 'url("../img/atk_grifo.png")')
    inimigo_lado.style.setProperty('--width_i_total', '-549px')
}
function boss_andando(){
    boss_lado.style.setProperty('--passos_b', 10)
    boss_lado.style.setProperty('--widht_boss', '203px')
    boss_lado.style.setProperty('--height_boss', '186px')
    boss_lado.style.setProperty('--boss', 'url("../img/boss.png")')
    boss_lado.style.setProperty('--width_b_total', '-2122px')
}
function boss_atacando(){
    boss_lado.style.setProperty('--passos_b', 3)
    boss_lado.style.setProperty('--widht_boss', '217px')
    boss_lado.style.setProperty('--height_boss', '182px')
    boss_lado.style.setProperty('--boss', 'url("../img/boss_atk.png")')
    boss_lado.style.setProperty('--width_b_total', '-652px')
}